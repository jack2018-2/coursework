create function checkrole() returns trigger
    language plpgsql
as
$$
begin
    if current_user = 'worker' then
        --raise exception 'pizda';
        raise notice 'pizda';
        return old;
    else
        return new;
    end if;
end;
$$;

alter function checkrole() owner to postgres;

