create function lang() returns text
    stable
    language plpgsql
as
$$
BEGIN
  RETURN current_setting('bookings.lang');
EXCEPTION
  WHEN undefined_object THEN
    RETURN NULL;
END;
$$;

alter function lang() owner to postgres;

