create view airports(airport_code, airport_name, city, coordinates, timezone) as
SELECT ml.airport_code,
       ml.airport_name ->> lang() AS airport_name,
       ml.city ->> lang()         AS city,
       ml.coordinates,
       ml.timezone
FROM airports_data ml;

comment on view airports is 'Airports';

comment on column airports.airport_code is 'Airport code';

comment on column airports.airport_name is 'Airport name';

comment on column airports.city is 'City';

comment on column airports.coordinates is 'Airport coordinates (longitude and latitude)';

comment on column airports.timezone is 'Airport time zone';

alter table airports
    owner to postgres;

