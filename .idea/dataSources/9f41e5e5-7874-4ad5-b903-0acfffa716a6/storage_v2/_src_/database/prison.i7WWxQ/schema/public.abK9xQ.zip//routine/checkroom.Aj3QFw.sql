create function checkroom() returns trigger
    language plpgsql
as
$$
declare
    bed_num text;
    bed_used text;
begin
    select bed_no into bed_num from cells where cell_no = new.cell_no;
    select count(prisoner_id) into bed_used from prisoners where prisoners.cell_no = new.cell_no;
    if cast(bed_used as int4) >= cast(bed_num as int4) then
        raise notice 'Комната переполнена';
        return old;
    else
        return new;
    end if;
end;
$$;

alter function checkroom() owner to postgres;

