create procedure checkdates()
    language plpgsql
as
$$
declare
    i record;
    prisoner_time int;
begin
    for i in select * from prisoners loop
        select cca.duration_years into prisoner_time from prisoners join prisoner_article pa on prisoners.prisoner_id = pa.prisoner_id join criminal_code_articles cca on cca.article_id = pa.article_id where prisoners.prisoner_id = i.prisoner_id;
        if i.arrived_date + prisoner_time <= current_date then
            raise notice 'Выпускаем зека!';
            delete from prisoners where prisoner_id = i.prisoner_id;
        end if;
    end loop;
end;
$$;

alter procedure checkdates() owner to postgres;

